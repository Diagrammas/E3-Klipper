import subprocess

# Replace 'YOUR_ALEXA_ROUTINE_TRIGGER_URL' with the actual URL provided by Alexa for your routine
alexa_routine_url = 'https://www.virtualsmarthome.xyz/url_routine_trigger/activate.php?trigger=21082953-33c7-4a7e-847a-a88ed2fbf855&token=2da5a9a7-0a28-4653-b0b2-ba8c4bca6150&response=html'

subprocess.run(['curl', alexa_routine_url])